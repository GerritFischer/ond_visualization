# ond_visualization
A simple tool to visualize the IBL Dataset using the ONE API

### Citations  
Brainrender: <br>
Claudi, F., Tyson, A., Petrucco, L., Margrie, T. W., Portugues, R., & Branco, T. (2021). Visualizing anatomically registered data with brainrender. eLife, 10. https://doi.org/10.7554/eLife.65751